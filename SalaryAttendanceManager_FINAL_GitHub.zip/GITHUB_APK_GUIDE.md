# GitHub APK Build Guide

1. Upload this ZIP to the repository root.
2. Keep `.github/workflows/build-apk.yml` in the repository.
3. The workflow automatically finds any `.zip` file in the repository root, so the ZIP filename does not matter.
4. Go to Actions → Build Android APK → Run workflow.
5. After a successful run, download the `SalaryAttendanceManager-APK` artifact.
